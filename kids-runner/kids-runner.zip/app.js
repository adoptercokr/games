const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over-screen');
const hud = document.getElementById('hud');
const scoreDisplay = document.getElementById('score-display');
const finalScore = document.getElementById('final-score');
const startBtn = document.getElementById('start-btn');
const restartBtn = document.getElementById('restart-btn');
const faceUpload = document.getElementById('face-upload');
const facePreview = document.getElementById('face-preview');
const previewCtx = facePreview.getContext('2d');
const shareBtn = document.getElementById('share-btn');

let gameLoopId;
let isPlaying = false;
let score = 0;
let frames = 0;
let gameSpeed = 5.5; // 시작 속도 상향
let bgX = 0;
let isInvincible = false;
let invincibleTimer = 0;

const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
const SoundEngine = {
    playTone(freq, type, duration, vol=0.1, slideFreq=null) {
        if(audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = type;
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        if (slideFreq) {
            osc.frequency.exponentialRampToValueAtTime(slideFreq, audioCtx.currentTime + duration);
        }
        
        gain.gain.setValueAtTime(vol, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + duration);
        
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
    },
    jump() { this.playTone(300, 'square', 0.2, 0.05, 600); },
    coin() { this.playTone(800, 'sine', 0.1, 0.05, 1200); },
    powerup() { 
        this.playTone(400, 'square', 0.1, 0.05, 600); 
        setTimeout(()=>this.playTone(600, 'square', 0.1, 0.05, 800), 100);
        setTimeout(()=>this.playTone(800, 'square', 0.2, 0.05, 1200), 200);
    },
    hit() { this.playTone(150, 'sawtooth', 0.4, 0.1, 50); },
    
    isPlayingBgm: false,
    bgmInterval: null,
    startBGM() {
        if(this.isPlayingBgm) return;
        this.isPlayingBgm = true;
        if(audioCtx.state === 'suspended') audioCtx.resume();
        const melody = [261.63, 329.63, 392.00, 523.25, 392.00, 329.63];
        let noteIdx = 0;
        this.bgmInterval = setInterval(() => {
            if(!this.isPlayingBgm) return;
            this.playTone(melody[noteIdx], 'triangle', 0.2, 0.03);
            noteIdx = (noteIdx + 1) % melody.length;
        }, 250);
    },
    stopBGM() {
        this.isPlayingBgm = false;
        clearInterval(this.bgmInterval);
    }
};

function resizeCanvas() {
    canvas.width = canvas.parentElement.clientWidth;
    canvas.height = canvas.parentElement.clientHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

const ASSETS = {
    background: 'assets/bg.png',
    body1: 'assets/body_run1.png',
    body2: 'assets/body_run2.png',
    obstacleDog: 'assets/obstacle.png',
    obstacleBird: 'assets/bird.png',
    obstacleTree: 'assets/tree.png',
    itemCandy: 'assets/item.png',
    itemChocolate: 'assets/chocolate.png'
};

const images = {};
let imagesLoaded = 0;
const totalImages = Object.keys(ASSETS).length;

for (let key in ASSETS) {
    images[key] = new Image();
    images[key].src = ASSETS[key];
    images[key].onload = () => { imagesLoaded++; };
}

let customFaceImage = null;

window.onload = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const faceData = urlParams.get('face');
    if (faceData) {
        customFaceImage = new Image();
        customFaceImage.onload = () => {
            startBtn.disabled = false;
            startBtn.innerText = "공유받은 얼굴로 시작하기";
            previewCtx.clearRect(0, 0, facePreview.width, facePreview.height);
            previewCtx.drawImage(customFaceImage, 0, 0, 100, 100);
            shareBtn.classList.remove('hidden');
        };
        customFaceImage.src = faceData;
    }
};

faceUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const img = new Image();
            img.onload = function() {
                previewCtx.clearRect(0, 0, facePreview.width, facePreview.height);
                previewCtx.save();
                previewCtx.beginPath();
                previewCtx.arc(50, 50, 50, 0, Math.PI * 2, true);
                previewCtx.closePath();
                previewCtx.clip();
                
                const size = Math.min(img.width, img.height);
                const sx = (img.width - size) / 2;
                const sy = (img.height - size) / 2;
                
                previewCtx.drawImage(img, sx, sy, size, size, 0, 0, 100, 100);
                previewCtx.restore();
                
                const dataUrl = facePreview.toDataURL('image/jpeg', 0.5);
                customFaceImage = new Image();
                customFaceImage.src = dataUrl;
                startBtn.disabled = false;
                startBtn.innerText = "게임 시작하기";
                
                const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?face=' + encodeURIComponent(dataUrl);
                window.history.pushState({path:newUrl},'',newUrl);
                shareBtn.classList.remove('hidden');
            }
            img.src = event.target.result;
        }
        reader.readAsDataURL(file);
    }
});

shareBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
        alert('얼굴이 포함된 게임 링크가 복사되었습니다! 친구들에게 보내보세요.');
    });
});

setTimeout(() => { 
    if(!customFaceImage) {
        startBtn.disabled = false; 
        startBtn.innerText = "기본 얼굴로 시작하기";
    }
}, 3000);

const player = {
    x: 50,
    y: 0,
    width: 60,
    height: 80,
    dy: 0,
    gravity: 0.85, // 중력 상향 (2단 점프 밸런스)
    jumpForce: -14.5,
    grounded: false,
    jumpCount: 0,
    
    draw() {
        if (isInvincible) {
            ctx.save();
            ctx.globalAlpha = (Math.floor(frames / 5) % 2 === 0) ? 0.6 : 1.0; // 반짝임 효과
            ctx.shadowBlur = 15;
            ctx.shadowColor = "gold";
        }

        if (imagesLoaded === totalImages) {
            const bodyImg = (!this.grounded) ? images.body2 : ((Math.floor(frames / 10) % 2 === 0) ? images.body1 : images.body2);
            ctx.drawImage(bodyImg, this.x, this.y + 20, this.width, this.height - 20);
        } else {
            ctx.fillStyle = '#feca57';
            ctx.fillRect(this.x, this.y + 30, this.width, this.height - 30);
        }
        
        if (customFaceImage) {
            ctx.drawImage(customFaceImage, this.x - 10, this.y - 20, 80, 80);
        } else {
            ctx.fillStyle = '#ffb8b8';
            ctx.beginPath();
            ctx.arc(this.x + this.width/2, this.y + 20, 30, 0, Math.PI*2);
            ctx.fill();
        }

        if (isInvincible) ctx.restore();
    },
    
    update() {
        this.dy += this.gravity;
        this.y += this.dy;
        const groundY = canvas.height - 50;
        if (this.y + this.height > groundY) {
            this.y = groundY - this.height;
            this.dy = 0;
            this.grounded = true;
            this.jumpCount = 0;
        } else {
            this.grounded = false;
        }
    },
    
    jump() {
        if (this.grounded || this.jumpCount < 2) {
            SoundEngine.jump();
            this.dy = this.jumpForce;
            this.grounded = false;
            this.jumpCount++;
        }
    }
};

let obstacles = [];
let items = [];

class Obstacle {
    constructor() {
        const r = Math.random();
        if (r < 0.35) this.type = 'dog';
        else if (r < 0.7) this.type = 'bird';
        else this.type = 'tree';
        
        this.x = canvas.width;
        if (this.type === 'dog') {
            this.width = 60; this.height = 50;
            this.y = canvas.height - 50 - this.height;
            this.img = images.obstacleDog;
        } else if (this.type === 'bird') {
            this.width = 50; this.height = 40;
            this.y = canvas.height - 130 - Math.random() * 80; // 공중 높이 다양화
            this.img = images.obstacleBird;
        } else { // tree
            this.width = 40; this.height = 90;
            this.y = canvas.height - 50 - this.height;
            this.img = images.obstacleTree;
        }
    }
    
    draw() {
        if (imagesLoaded === totalImages) {
            ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
        } else {
            ctx.fillStyle = '#2d3436';
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
    
    update() {
        // 새는 캐릭터를 향해 더 빨리 날아옴
        this.x -= gameSpeed * (this.type === 'bird' ? 1.3 : 1.0);
        this.draw();
    }
}

class Item {
    constructor() {
        this.type = Math.random() < 0.15 ? 'chocolate' : 'candy'; // 15% 확률로 초콜릿
        this.radius = this.type === 'chocolate' ? 25 : 20;
        this.x = canvas.width;
        this.y = canvas.height - 100 - Math.random() * 100;
    }
    
    draw() {
        if (imagesLoaded === totalImages) {
            const img = this.type === 'chocolate' ? images.itemChocolate : images.itemCandy;
            ctx.drawImage(img, this.x - this.radius, this.y - this.radius, this.radius*2, this.radius*2);
        } else {
            ctx.fillStyle = this.type === 'chocolate' ? '#8B4513' : '#ff9ff3';
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI*2);
            ctx.fill();
        }
    }
    
    update() {
        this.x -= gameSpeed;
        this.draw();
    }
}

function handleInput() {
    if (isPlaying) player.jump();
}
window.addEventListener('keydown', (e) => {
    if (e.code === 'Space' || e.code === 'ArrowUp') handleInput();
});
canvas.addEventListener('mousedown', handleInput);
canvas.addEventListener('touchstart', (e) => {
    if(isPlaying) e.preventDefault();
    handleInput();
}, {passive: false});

function spawnEntities() {
    // 2단 점프 난이도에 맞게 스폰 간격 좁힘
    if (frames % Math.max(50, 110 - Math.floor(gameSpeed*5)) === 0) {
        obstacles.push(new Obstacle());
    }
    if (frames % 80 === 0) {
        items.push(new Item());
    }
}

function checkCollisions() {
    let pBox = { x: player.x + 15, y: player.y + 15, w: player.width - 30, h: player.height - 30 };
    
    for (let i = 0; i < obstacles.length; i++) {
        let obs = obstacles[i];
        let oBox = { x: obs.x + 10, y: obs.y + 10, w: obs.width - 20, h: obs.height - 20 };
        if (pBox.x < oBox.x + oBox.w &&
            pBox.x + pBox.w > oBox.x &&
            pBox.y < oBox.y + oBox.h &&
            pBox.y + pBox.h > oBox.y) {
            if (!isInvincible) {
                gameOver();
                return; // 확실한 게임 오버 처리
            }
        }
    }
    for (let i = items.length - 1; i >= 0; i--) {
        let item = items[i];
        let iBox = { x: item.x - item.radius + 5, y: item.y - item.radius + 5, w: item.radius*2 - 10, h: item.radius*2 - 10 };
        if (pBox.x < iBox.x + iBox.w &&
            pBox.x + pBox.w > iBox.x &&
            pBox.y < iBox.y + iBox.h &&
            pBox.y + pBox.h > iBox.y) {
            
            if (item.type === 'chocolate') {
                SoundEngine.powerup();
                isInvincible = true;
                invincibleTimer = frames + 300; // 5초 무적 (60fps 기준)
                score += 50; // 초콜릿 50점
            } else {
                SoundEngine.coin();
                score += 10;
            }
            
            items.splice(i, 1);
            scoreDisplay.innerText = score;
        }
    }
}

function drawBackground() {
    if (imagesLoaded === totalImages) {
        bgX -= gameSpeed * 0.5;
        if (bgX <= -canvas.width) bgX = 0;
        ctx.drawImage(images.background, bgX, 0, canvas.width, canvas.height);
        ctx.drawImage(images.background, bgX + canvas.width, 0, canvas.width, canvas.height);
    } else {
        ctx.fillStyle = '#1dd1a1'; 
        ctx.fillRect(0, canvas.height - 50, canvas.width, 50);
    }
}

function update() {
    if (!isPlaying) return;
    
    if (isInvincible && frames > invincibleTimer) {
        isInvincible = false;
    }
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBackground();
    
    player.update();
    player.draw();
    
    spawnEntities();
    
    for (let i = obstacles.length - 1; i >= 0; i--) {
        obstacles[i].update();
        if (obstacles[i].x + obstacles[i].width < 0) {
            obstacles.splice(i, 1);
            score += 1;
            scoreDisplay.innerText = score;
        }
    }
    
    for (let i = items.length - 1; i >= 0; i--) {
        items[i].update();
        if (items[i].x + items[i].radius < 0) items.splice(i, 1);
    }
    
    if (isPlaying) checkCollisions();
    
    // 속도 증가 (난이도 상향)
    if (frames > 0 && frames % 350 === 0) gameSpeed += 0.5;
    
    frames++;
    if (isPlaying) {
        gameLoopId = requestAnimationFrame(update);
    }
}

function startGame() {
    startScreen.classList.add('hidden');
    gameOverScreen.classList.add('hidden');
    hud.classList.remove('hidden');
    
    obstacles = [];
    items = [];
    score = 0;
    frames = 0;
    gameSpeed = 5.5;
    bgX = 0;
    isInvincible = false;
    player.y = canvas.height - 150;
    player.dy = 0;
    player.grounded = false;
    player.jumpCount = 0;
    scoreDisplay.innerText = score;
    
    SoundEngine.startBGM();
    isPlaying = true;
    update();
}

function gameOver() {
    isPlaying = false;
    cancelAnimationFrame(gameLoopId);
    
    SoundEngine.stopBGM();
    SoundEngine.hit();
    
    hud.classList.add('hidden');
    gameOverScreen.classList.remove('hidden');
    finalScore.innerText = score;
}

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);
