const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over-screen');
const scoreVal = document.getElementById('score-val');
const waveVal = document.getElementById('wave-val');
const healthVal = document.getElementById('health-val');
const finalScore = document.getElementById('final-score');
const startBtn = document.getElementById('start-btn');
const restartBtn = document.getElementById('restart-btn');

let gameLoopId;
let isPlaying = false;
let score = 0;
let wave = 1;
let health = 5;
let frames = 0;
let isLaserActive = false;
let laserTimer = 0;
let muzzleFlashActive = 0;

// ─── Audio Engine (Dynamic Web Audio API Synth Engine) ────────────────────────
const SFX = {
    ctx: null, master: null, ready: false, lastHit: 0, BGMInterval: null,
    
    init() {
        if (this.ready) return;
        this.ready = true;
        try {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            this.master = this.ctx.createGain();
            this.master.gain.value = 0.4;
            this.master.connect(this.ctx.destination);
        } catch(e) {}
    },
    
    tone(freq1, freq2, dur, vol, type='sawtooth') {
        if (!this.ctx) return;
        if (this.ctx.state !== 'running') {
            try { this.ctx.resume(); } catch(e) {}
        }
        try {
            const n = this.ctx.currentTime;
            const o = this.ctx.createOscillator();
            const g = this.ctx.createGain();
            o.type = type;
            o.frequency.setValueAtTime(freq1, n);
            o.frequency.exponentialRampToValueAtTime(Math.max(0.01, freq2), n + dur);
            g.gain.setValueAtTime(vol, n);
            g.gain.exponentialRampToValueAtTime(0.001, n + dur);
            o.connect(g); g.connect(this.master);
            o.start(n); o.stop(n + dur);
        } catch(e) {}
    },
    
    shot() { this.init(); this.tone(900, 80, 0.12, 0.08, 'sawtooth'); },
    hit() {
        this.init();
        const now = Date.now();
        if (now - this.lastHit < 40) return;
        this.lastHit = now;
        this.tone(130, 30, 0.06, 0.05, 'triangle');
    },
    kill() { this.init(); this.tone(80, 1, 0.35, 0.18, 'sawtooth'); },
    item() {
        this.init();
        this.tone(523.25, 1046.50, 0.15, 0.12, 'sine');
        setTimeout(() => { this.tone(1046.50, 2093.00, 0.2, 0.12, 'sine'); }, 80);
    },
    
    startBGM() {
        this.init();
        if (this.BGMInterval) clearInterval(this.BGMInterval);
        
        let beat = 0;
        const playBeat = () => {
            if (!isPlaying) {
                clearInterval(this.BGMInterval);
                this.BGMInterval = null;
                return;
            }
            
            // Sub-bass dark kick beat
            if (beat % 4 === 0) {
                this.tone(55, 0.01, 0.4, 0.12, 'sine');
            } else if (beat % 4 === 2) {
                this.tone(150, 10, 0.1, 0.04, 'triangle'); 
            }
            
            // Dark bass synth sequence
            const notes = [110, 130, 146, 165, 146, 130];
            const note = notes[beat % notes.length];
            if (beat % 2 === 0) {
                this.tone(note, note * 0.98, 0.18, 0.025, 'triangle');
            }
            
            beat++;
        };
        this.BGMInterval = setInterval(playBeat, 260); 
    }
};

// ─── Visual Assets (Seamless Fallback Loading) ────────────────────────────────
const playerImg = new Image();
const zombieImg = new Image();
const bgImg = new Image();

let imagesLoaded = 0;
function onAssetLoaded() {
    imagesLoaded++;
}

playerImg.onload = onAssetLoaded;
zombieImg.onload = onAssetLoaded;
bgImg.onload = onAssetLoaded;

function loadWithFallback(imgObj, localSrc, fallbackSrc) {
    imgObj.src = localSrc;
    imgObj.onerror = () => {
        imgObj.src = fallbackSrc;
        imgObj.onerror = null;
    };
}

const brainDir = 'C:/Users/mj/.gemini/antigravity/brain/f2e47261-912f-4025-a15c-1467ab7565e4';
loadWithFallback(playerImg, 'assets/player1.png', `${brainDir}/player1_1778503971293.png`);
loadWithFallback(zombieImg, 'assets/zombie1.png', `${brainDir}/zombie1_1778503989090.png`);
loadWithFallback(bgImg, 'assets/bg.png', `${brainDir}/bg_1778503952171.png`);

let bgCanvas = document.createElement('canvas');
let bgCtx = bgCanvas.getContext('2d');
let bgPrepared = false;

function resize() {
    canvas.width = canvas.parentElement.clientWidth;
    canvas.height = canvas.parentElement.clientHeight;
    bgPrepared = false;
}
window.addEventListener('resize', resize);
resize();

function prepareBg() {
    if (!bgImg.width) return;
    let w = canvas.width;
    let h = canvas.width * (bgImg.height / bgImg.width);
    bgCanvas.width = w;
    bgCanvas.height = h * 2; 
    
    bgCtx.drawImage(bgImg, 0, 0, w, h);
    bgCtx.save();
    bgCtx.translate(0, h * 2);
    bgCtx.scale(1, -1);
    bgCtx.drawImage(bgImg, 0, 0, w, h);
    bgCtx.restore();
    
    bgPrepared = true;
}

const player = {
    x: canvas.width / 2,
    y: canvas.height - 110,
    width: 150,
    height: 150,
    targetX: canvas.width / 2,
    
    draw() {
        if (imagesLoaded >= 3) {
            // Actively walking status
            let isMoving = Math.abs(this.targetX - this.x) > 2.5;
            
            // Stepping sway and weight transfer oscillation
            let walkBob = isMoving ? Math.abs(Math.sin(frames * 0.25)) * 5 : 0;
            let walkSway = isMoving ? Math.sin(frames * 0.25) * 0.05 : 0;
            let idleBob = Math.sin(frames * 0.1) * 2;
            
            ctx.save();
            ctx.translate(this.x, this.y + walkBob + idleBob);
            ctx.rotate(walkSway + (Math.sin(frames * 0.05) * 0.01));
            
            // Draw Procedural Tactical Boots under body
            let stepCycle = isMoving ? Math.sin(frames * 0.25) * 15 : 0;
            ctx.fillStyle = '#1c1d22'; // Boot leather
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 1.5;
            
            // Left Boot
            ctx.beginPath();
            ctx.roundRect(-22, 10 + stepCycle, 13, 20, 5);
            ctx.fill();
            ctx.stroke();
            
            // Right Boot
            ctx.beginPath();
            ctx.roundRect(8, 10 - stepCycle, 13, 20, 5);
            ctx.fill();
            ctx.stroke();
            
            // Draw Player Core Sprite (Remains 100% consistent, no different-character mismatch!)
            ctx.drawImage(playerImg, -this.width/2, -this.height/2, this.width, this.height);
            
            // Draw Beautiful Muzzle Flash matching rifle barrel!
            if (muzzleFlashActive > 0) {
                ctx.save();
                ctx.translate(18, -this.height/2 + 10);
                ctx.fillStyle = '#ff9f43';
                ctx.shadowBlur = 30;
                ctx.shadowColor = '#f1c40f';
                ctx.beginPath();
                for(let k=0; k<8; k++) {
                    let angle = (k * Math.PI)/4;
                    let r = (k % 2 === 0) ? 22 : 8;
                    ctx.lineTo(Math.cos(angle)*r, Math.sin(angle)*r);
                }
                ctx.closePath();
                ctx.fill();
                ctx.restore();
                muzzleFlashActive--;
            }
            
            ctx.restore();
        } else {
            ctx.fillStyle = '#1e90ff';
            ctx.fillRect(this.x - this.width/2, this.y - this.height/2, this.width, this.height);
        }
    },
    update() {
        this.y = canvas.height - 110;
        this.x += (this.targetX - this.x) * 0.2;
        if(this.x < this.width/2) this.x = this.width/2;
        if(this.x > canvas.width - this.width/2) this.x = canvas.width - this.width/2;
    }
};

let bullets = [];
let zombies = [];
let particles = [];
let items = [];

function spawnZombie() {
    let count = Math.floor(Math.random() * 3) + 2; 
    for(let i=0; i<count; i++) {
        let isGiant = Math.random() < 0.15;
        let size = isGiant ? 240 : 130;
        let hp = isGiant ? (12 + wave * 5) : (3 + Math.floor(wave / 2));
        let speed = isGiant ? (0.2 + wave * 0.02) : (0.4 + Math.random() * 0.3 + wave * 0.04);
        
        zombies.push({
            x: Math.random() * (canvas.width - size) + size/2,
            y: -150 - Math.random() * 80,
            width: size,
            height: size,
            speed: speed,
            hp: hp,
            maxHp: hp,
            isGiant: isGiant,
            animOffset: Math.floor(Math.random() * 100)
        });
    }
}

function killZombie(index, z) {
    zombies.splice(index, 1);
    score += z.isGiant ? 300 * wave : 100 * wave;
    SFX.kill();
    
    if(Math.random() < 0.08 || (z.isGiant && Math.random() < 0.3)) { 
        let type = (Math.random() < 0.15) ? 'laser' : 'coin'; 
        items.push({
            x: z.x, y: z.y,
            radius: z.isGiant ? 22 : 16,
            speed: 2.5,
            color: type === 'laser' ? '#ff4757' : '#f1c40f',
            type: type
        });
    }
    
    updateHUD();
    createParticles(z.x, z.y, '#2ed573');
}

function shoot() {
    let count = Math.min(7, 1 + Math.floor(wave / 3));
    muzzleFlashActive = 3; 
    SFX.shot();
    
    for(let i=0; i<count; i++) {
        let offsetX = (i - (count-1)/2) * 15;
        bullets.push({
            x: player.x + 18 + offsetX,
            y: player.y - player.height/2 + 10,
            width: 6,
            height: 28,
            speed: 22,
            color: '#00ffff'
        });
    }
}

function createParticles(x, y, color) {
    for(let i=0; i<15; i++) {
        particles.push({
            x: x, y: y,
            vx: (Math.random()-0.5)*12,
            vy: (Math.random()-0.5)*12,
            life: 1.0,
            color: color
        });
    }
}

function updateGame() {
    if(!isPlaying) return;
    
    if (imagesLoaded >= 3 && !bgPrepared) prepareBg();

    if (bgPrepared) {
        let totalH = bgCanvas.height;
        let bgY = (frames * 3) % totalH; 
        
        ctx.drawImage(bgCanvas, 0, bgY - totalH, canvas.width, totalH);
        ctx.drawImage(bgCanvas, 0, bgY, canvas.width, totalH);
        if (bgY + totalH < canvas.height) {
            ctx.drawImage(bgCanvas, 0, bgY + totalH, canvas.width, totalH);
        }
    } else {
        ctx.fillStyle = '#0d0d12';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    
    player.update();
    player.draw();
    
    if (isLaserActive) {
        if (frames > laserTimer) {
            isLaserActive = false;
        } else {
            ctx.fillStyle = (frames % 4 < 2) ? '#ff4757' : '#ffa502';
            ctx.shadowBlur = 30;
            ctx.shadowColor = '#ff4757';
            ctx.fillRect(player.x + 18 - 40, 0, 80, player.y - player.height/2 + 20);
            ctx.shadowBlur = 0;
            
            for(let i=zombies.length-1; i>=0; i--) {
                let z = zombies[i];
                if(Math.abs(z.x - (player.x + 18)) < z.width/2 + 40) {
                    z.hp -= 2; 
                    createParticles(z.x, z.y + z.height/2, '#ffa502');
                    if(z.hp <= 0) killZombie(i, z);
                }
            }
        }
    } else {
        if(frames % 7 === 0) shoot();
    }
    
    let spawnRate = Math.max(15, 50 - wave * 4); 
    if(frames % spawnRate === 0) spawnZombie();
    
    // Draw bullets (Neon Glowing Laser Bolts)
    for(let i=bullets.length-1; i>=0; i--) {
        let b = bullets[i];
        b.y -= b.speed;
        
        ctx.save();
        ctx.fillStyle = b.color;
        ctx.shadowBlur = 15;
        ctx.shadowColor = b.color;
        
        ctx.beginPath();
        ctx.roundRect(b.x - b.width/2, b.y, b.width, b.height, 3);
        ctx.fill();
        ctx.restore();
        
        if(b.y < -50) bullets.splice(i, 1);
    }
    
    // Draw Items (Premium Animated Vector Items)
    for(let i=items.length-1; i>=0; i--) {
        let item = items[i];
        item.y += item.speed;
        
        ctx.save();
        ctx.shadowBlur = 15;
        ctx.shadowColor = item.color;
        
        if (item.type === 'laser') {
            // Draw Sci-Fi Laser Power Cell (Battery)
            let w = item.radius * 1.6;
            let h = item.radius * 2.4;
            
            ctx.fillStyle = 'rgba(255, 71, 87, 0.2)';
            ctx.fillRect(item.x - w/2 - 4, item.y - h/2 - 4, w + 8, h + 8);
            
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2.5;
            ctx.strokeRect(item.x - w/2, item.y - h/2, w, h);
            
            ctx.fillStyle = '#fff';
            ctx.fillRect(item.x - w/4, item.y - h/2 - 4, w/2, 4);
            
            let chargeBlocks = 3;
            let pad = 3;
            let bh = (h - (chargeBlocks + 1) * pad) / chargeBlocks;
            ctx.fillStyle = (frames % 10 < 5) ? '#ff4757' : '#ffa502';
            for (let b = 0; b < chargeBlocks; b++) {
                ctx.fillRect(item.x - w/2 + pad, item.y - h/2 + pad + b * (bh + pad), w - pad * 2, bh);
            }
            
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('⚡', item.x, item.y);
        } else {
            // Draw Premium 3D Golden Coin
            ctx.fillStyle = '#d35400';
            ctx.beginPath();
            ctx.arc(item.x, item.y, item.radius, 0, Math.PI*2);
            ctx.fill();
            
            let grad = ctx.createRadialGradient(item.x - 3, item.y - 3, 2, item.x, item.y, item.radius - 2);
            grad.addColorStop(0, '#fff');
            grad.addColorStop(0.3, '#f1c40f');
            grad.addColorStop(1, '#f39c12');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(item.x, item.y, item.radius - 2, 0, Math.PI*2);
            ctx.fill();
            
            ctx.strokeStyle = '#f39c12';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(item.x, item.y, item.radius * 0.6, 0, Math.PI*2);
            ctx.stroke();
            
            ctx.fillStyle = '#d35400';
            ctx.font = 'bold 14px "Segoe UI",sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('$', item.x, item.y + 0.5);
            
            ctx.fillStyle = '#fff';
            ctx.fillText('$', item.x, item.y - 0.5);
            
            if (frames % 40 < 10) {
                ctx.fillStyle = '#fff';
                ctx.beginPath();
                ctx.arc(item.x + Math.sin(frames)*6, item.y + Math.cos(frames)*6, 2, 0, Math.PI*2);
                ctx.fill();
            }
        }
        ctx.restore();
        
        let dx = item.x - player.x;
        let dy = item.y - player.y;
        if(Math.sqrt(dx*dx + dy*dy) < (item.radius + player.width/2 - 40)) {
            items.splice(i, 1);
            SFX.item();
            if(item.type === 'laser') {
                isLaserActive = true;
                laserTimer = frames + 180;
            } else {
                score += 50;
            }
            updateHUD();
            createParticles(player.x, player.y, item.color);
            continue;
        }
        
        if(item.y > canvas.height + 50) items.splice(i, 1);
    }
    
    // Draw zombies
    for(let i=zombies.length-1; i>=0; i--) {
        let z = zombies[i];
        z.y += z.speed;
        
        if (imagesLoaded >= 3) {
            // Decayed, limping, slow weight shifts for zombies
            let zStep = Math.sin((frames + z.animOffset) * 0.12) * 11;
            let zBob = Math.abs(Math.sin((frames + z.animOffset) * 0.15)) * (z.isGiant ? 4 : 8);
            let zSway = Math.sin((frames + z.animOffset) * 0.08) * 0.06;
            
            ctx.save();
            ctx.translate(z.x, z.y - zBob);
            ctx.rotate(zSway);
            
            // Draw Decayed Green Zombie Feet dragging
            ctx.fillStyle = '#1c2d22'; // Rotten boot leather
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 1.2;
            
            // Left Decayed Foot
            ctx.beginPath();
            ctx.roundRect(-16, 8 + zStep, 10, 16, 4);
            ctx.fill();
            ctx.stroke();
            
            // Right Decayed Foot
            ctx.beginPath();
            ctx.roundRect(6, 8 - zStep, 10, 16, 4);
            ctx.fill();
            ctx.stroke();
            
            // Draw Zombie Core Sprite (Consistent image)
            ctx.drawImage(zombieImg, -z.width/2, -z.height/2, z.width, z.height);
            ctx.restore();
        } else {
            ctx.fillStyle = z.isGiant ? '#218c53' : '#2ed573';
            ctx.fillRect(z.x - z.width/2, z.y - z.height/2, z.width, z.height);
        }
        
        if(z.hp < z.maxHp) {
            let bw = z.isGiant ? 120 : 60;
            let bh = z.isGiant ? 10 : 6;
            ctx.fillStyle = 'red';
            ctx.fillRect(z.x - bw/2, z.y - z.height/2 - 20, bw, bh);
            ctx.fillStyle = '#2ed573';
            ctx.fillRect(z.x - bw/2, z.y - z.height/2 - 20, bw * (z.hp/z.maxHp), bh);
        }
        
        let dx = z.x - player.x;
        let dy = z.y - player.y;
        if(Math.sqrt(dx*dx + dy*dy) < (z.width/2 + player.width/2 - 40)) {
            zombies.splice(i, 1);
            health -= z.isGiant ? 2 : 1;
            SFX.hit();
            updateHUD();
            createParticles(player.x, player.y, 'red');
            if(health <= 0) gameOver();
            continue;
        }
        
        for(let j=bullets.length-1; j>=0; j--) {
            let b = bullets[j];
            if(Math.abs(z.x - b.x) < z.width/2 && Math.abs(z.y - b.y) < z.height/2) {
                z.hp--;
                bullets.splice(j, 1);
                SFX.hit();
                createParticles(b.x, b.y, '#f1c40f');
                if(z.hp <= 0) {
                    killZombie(i, z);
                    break;
                }
            }
        }
        
        if(z.y > canvas.height + 150) {
            zombies.splice(i, 1);
            health -= z.isGiant ? 2 : 1;
            updateHUD();
            if(health <= 0) gameOver();
        }
    }
    
    for(let i=particles.length-1; i>=0; i--) {
        let p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.05;
        if(p.life <= 0) {
            particles.splice(i, 1);
        } else {
            ctx.globalAlpha = p.life;
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, 4, 0, Math.PI*2);
            ctx.fill();
            ctx.globalAlpha = 1.0;
        }
    }
    
    if(frames > 0 && frames % 500 === 0) {
        wave++;
        updateHUD();
    }
    
    frames++;
    if(isPlaying) gameLoopId = requestAnimationFrame(updateGame);
}

function updateHUD() {
    scoreVal.innerText = score.toLocaleString();
    waveVal.innerText = wave;
    let hStr = '';
    for(let i=0; i<Math.max(0, health); i++) hStr += '❤️';
    healthVal.innerText = hStr;
}

function startGame() {
    try {
        startScreen.classList.add('hidden');
        gameOverScreen.classList.add('hidden');
        
        score = 0;
        wave = 1;
        health = 5; 
        frames = 0;
        bullets = [];
        zombies = [];
        particles = [];
        items = [];
        isLaserActive = false;
        laserTimer = 0;
        
        player.x = canvas.width / 2;
        player.targetX = player.x;
        updateHUD();
        
        isPlaying = true;
        SFX.startBGM(); 
        updateGame();
    } catch(e) {
        alert("Error: " + e.message);
    }
}

function gameOver() {
    isPlaying = false;
    cancelAnimationFrame(gameLoopId);
    gameOverScreen.classList.remove('hidden');
    document.getElementById('restart-btn').className = "btn-modern pulse";
    finalScore.innerText = score.toLocaleString();
}

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', startGame);

let isDragging = false;

function getX(e) {
    let rect = canvas.getBoundingClientRect();
    if(e.touches && e.touches.length > 0) {
        return e.touches[0].clientX - rect.left;
    }
    return e.clientX - rect.left;
}

canvas.addEventListener('mousedown', (e) => { isDragging = true; player.targetX = getX(e); });
canvas.addEventListener('mousemove', (e) => { if(isDragging) player.targetX = getX(e); });
canvas.addEventListener('mouseup', () => isDragging = false);
canvas.addEventListener('touchstart', (e) => { isDragging = true; player.targetX = getX(e); }, {passive: true});
canvas.addEventListener('touchmove', (e) => { if(isDragging) player.targetX = getX(e); }, {passive: true});
canvas.addEventListener('touchend', () => isDragging = false);
